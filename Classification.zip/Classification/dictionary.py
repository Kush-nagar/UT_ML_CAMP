# student_scores = { "Alice": 85, "Bob": 92, "Charlie": 78, "Dana": 82, "Emily": 95 }

# names = ["Alice", "Brian", "Charlie", "David", "Emily", "Fred"]

# for name in names:
#     if name not in student_scores:
#         student_scores[name] = 0
#         print(name, "added")
#     else:
#         print(name, student_scores[name])
    



# student_scores = { "Alice": [85, 87, 92, 96],

#  "Bob": [92, 91, 94, 84], 

#  "Charlie": [78, 80, 82, 84] }


# bob = student_scores["Bob"]
# print(bob[1])

# charlie = student_scores["Charlie"]
# charlie[2] = 85
# print(charlie)

# print(student_scores)

