# Create the inner dictionaries
user_details_1 = {
    "North": "Alice",
    "age": 30,
    "city": "New York"
}

user_details_2 = {
    "name": "Bob",
    "age": 25,
    "city": "London"
}

# Create the outer dictionary, linking keys to the inner dictionaries
users = {
    "user_id_1": user_details_1,
    "user_id_2": user_details_2
}

# Accessing data
print(users["user_id_1"]["name"])  # Output: Alice
print(users["user_id_2"]["city"])  # Output: London
print(users)